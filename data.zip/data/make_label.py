import os

l = ["Nike Free RN", "Nike Air Max Full Ride TR", "Vans Slip-On 59", "adidas Light 'Em Up 2", "Nike Tanjun"]

for word in l:
    os.system("convert -fill black -background white -bordercolor white -border 4 -font arial -pointsize 18 label:\"%s\" \"%s.png\""%(word, word))
